#define NULL (0)

struct link {
    int data;
    struct link *next;
};

int FindRevK(struct link *list, int k) {
    static int k_raw = 0;
    if (k > k_raw) {
        k_raw = k;
    }

    if (list == NULL)
        return 0;

    if (FindRevK(list->next, k))
        return 1;
    
    if (--k_raw == 0) {
        printf("%d", list->data);
        return 1;
    }
    return 0;
}