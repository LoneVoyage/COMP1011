#define NULL (0)

struct link {
    int data;
    struct link *next;
};

struct link_queue {
    struct link *front;
    struct link *rear;
    int size;
};

void InitQueue(struct link_queue *Q) {
    Q->front    = NULL;
    Q->rear     = NULL;
    Q->size     = 0;
}

int EnQueue(struct link_queue *Q, int nodeData) {
    struct link *p = (struct link *)malloc(sizeof(struct link));
    p->data = nodeData;         
    p->next = NULL;                // ①创建数据节点p

    if (Q->rear == NULL) {         // ②将新节点加入队列
        Q->front = p;
        
    } else {
        Q->rear->next = p;
    }
    Q->rear = p;                   // ③将队列尾指针指向新节点
    Q->size++;                     // 队列大小+1
    return 1;		               // 入队成功
}

int DeQueue(struct link_queue *Q, int *nodeData) {
    if (Q->front == NULL)           // 空队列
        return -1;

    struct link *del = Q->front;
    *nodeData = del->data;

    Q->front = del->next;           // 删除队头节点
    Q->size--;                      // 队列大小-1
    if(Q->front == NULL) 
    	Q->rear = NULL;             // 若删除后队列为空，则将rear置空
    free(del);                      // 释放内存
    return 1;                       // 出队成功
}