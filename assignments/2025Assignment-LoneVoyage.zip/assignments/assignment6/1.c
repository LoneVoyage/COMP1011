#define NULL (0)

struct link {
    int data;
    struct link *next;
};

void DeleteX_NonRecur(struct link *head, int x) {
    struct link *prev = head;
    struct link *curr = head->next;
    while (curr != NULL) {
        if (curr->data == x) {
            prev->next = curr->next;
            free(curr);
            curr = prev;
        }
        prev = curr;
        curr = curr->next;
    }
}

void DeleteX_Recur(struct link *prev, int x) {
    if (prev == NULL || prev->next == NULL)
        return;

    struct link *curr = prev->next;
    if (curr->data == x) {
        prev->next = curr->next;
        free(curr);
        curr = prev;
    }
    DeleteX_Recur(curr, x);
}