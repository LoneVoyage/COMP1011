struct Date {
	int year, month, day;
};

struct EmploymentInfo {
	char department[32],
		professional_title[32],
		position[32];
};

struct Employee {
	char name,
		gender;	// 'M' / 'F'
	struct Date birth_date;
	struct EmploymentInfo employment_info;
};
