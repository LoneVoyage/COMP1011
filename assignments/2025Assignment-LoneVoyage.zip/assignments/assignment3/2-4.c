#include <stdio.h>

struct Date {
	int year, month, day;
};

struct EmploymentInfo {
	char department[32],
		title[32],
		position[32];
};

struct Employee {
	char name[32],
		gender;	// 'M' / 'F'
	struct Date birth_date;
	struct EmploymentInfo employment_info;
};

int datecmp(struct Date a, struct Date b);
void input_employee(struct Employee *employee);

int main(void) {
	struct Employee employees[5];
	struct Date earliest_date = {0x7fffffff, 0x7fffffff, 0x7fffffff};

	for (int i = 0; i < 5; ++i) {
		input_employee(employees + i);
		if (datecmp(employees[i].birth_date, earliest_date) < 0) {
			earliest_date = employees[i].birth_date;
		}
	}

	for (int i = 0; i < 5; ++i) {
		if (datecmp(employees[i].birth_date, earliest_date) == 0) {
			puts(employees[i].name);
		}
	}
	return 0;
}

int datecmp(struct Date a, struct Date b) {
	if (a.year < b.year) return -1;
	if (a.year > b.year) return 1;
	if (a.month < b.month) return -1;
	if (a.month > b.month) return 1;
	if (a.day < b.day) return -1;
	if (a.day > b.day) return 1;
	return 0;
}

void input_employee(struct Employee *employee) {
	scanf("%s %c %d %d %d %s %s %s",
		employee->name,
		&employee->gender,
		&employee->birth_date.year,
		&employee->birth_date.month,
		&employee->birth_date.day,
		employee->employment_info.department,
		employee->employment_info.title,
		employee->employment_info.position
	);
}