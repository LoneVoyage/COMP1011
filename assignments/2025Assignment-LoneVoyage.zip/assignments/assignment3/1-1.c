#include <stdio.h>

int *Input(int *dst);
int Sum(int *beg, int *end);
int Mean(int *beg, int *end);
int CountIfGreaterThan(int *beg, int *end, int num);

int main(void)
{
	int score[40], *end, mean, cnt;
	end = Input(score);
	mean = Mean(score, end);
	cnt = CountIfGreaterThan(score, end, mean);
	printf("%d", cnt);
}

int *Input(int *dst)
{
	int input;
	while (scanf("%d", &input) == 1 && input >= 0)
	{
		*dst++ = input;
	}
	return dst;
}

int Sum(int *beg, int *end)
{
	int sum = 0;
	while (beg != end)
	{
		sum += *beg++;
	}
	return sum;
}

int Mean(int *beg, int *end)
{
	if (beg == end)
		return -1;
	
	return Sum(beg, end) / (end - beg);
}

int CountIfGreaterThan(int *beg, int *end, int num)
{
	int res = 0;
	while (beg != end)
	{
		res += *beg++ > num;
	}
	return res;
}