#include <stdio.h>
#include <string.h>

const char *DAY_OF_THE_WEEK[] = {
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday",
};

int main() {
	char input[256];
	scanf("%s", input);
	for (int i = 0; i < 7; ++i) {
		if (strcmp(input, DAY_OF_THE_WEEK[i]) == 0) {
			printf("%d\n", i);
			return 0;
		}
	}
	
	puts("Error: invalid day!");
	return 0;
}