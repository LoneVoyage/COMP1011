#include <stdio.h>

int my_pow(int n, int k) {
    if (n < 1 || k < 1) // bad definition: non-positive
        return -1;
    
    if (k == 1)
        return n;

    return my_pow(n, k - 1) * n;
}

int main(void) {
    int n, k;
    scanf("%d%d", &n, &k);
    printf("%d\n", my_pow(n, k));
    return 0;
}