#include <stdio.h>

int max(int a, int b) {
    return a > b? a: b;
}

int main(void) {
    int a, b;
    scanf("%d%d", &a, &b);
    printf("%d\n", max(a, b));
    return 0;
}