#include <stdio.h>

int lcm(int a, int b) {
    if (a < b)
        return lcm(b, a);   // swap
    
    if (b < 1)  // bad definition: non-positive
        return -1;

    int res = a;
    while (res % b) {
        res += a;
    }
    return res;
}

int main(void) {
    int a, b;
    scanf("%d%d", &a, &b);
    printf("%d\n", lcm(a, b));
    return 0;
}