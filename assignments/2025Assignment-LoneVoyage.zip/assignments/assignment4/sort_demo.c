#include <stdio.h>
#include <stdlib.h>

void display(int arr[], int n);
void insertionSort(int arr[], int n);
void bubbleSort(int arr[], int n);
void selectionSort(int arr[],int n);
void mergeSort(int arr[],int tmp[],int left, int right);
void quickSort(int arr[], int low, int high);

int main()
{
    int a[20]={1,3,4,9,6,5,4,0,8,7};
    int tmp[20];

    //insertionSort(a,10);
    bubbleSort(a,10);
    //selectionSort(a,10);
    //mergeSort(a,tmp,0,9);
    //quickSort(a,0,9);
    display(a,10);

    return 0;
}

void display(int arr[], int n)
{
    for(int i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }
    printf("\n");
}
// ����������
void insertionSort(int arr[], int n)
{
    int i,j,key;
    for(i=0;i<n-1;i++)
    {
        key=arr[i+1];
        for(j=i+1;j>0 && arr[j-1]>key;j--)
        {
            arr[j]=arr[j-1];
        }
        arr[j]=key;
    }
}

void bubbleSort(int arr[], int n)
{
    int i,j,noswap;

    for(i=0;i<n-1;i++)
    {
        noswap=1;
        for(j=0;j<n-1-i;j++)
        {
            if(arr[j]>arr[j+1])
            {
                int tmp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=tmp;
                noswap=0;
            }
        }
        if(noswap)
            break;
    }
}

void selectionSort(int arr[],int n)
{
    int i,j,k;

    for(i=0;i<n-1;i++)
    {
        k=i;
        for(j=i+1;j<n;j++)
        {
            if(arr[k]>arr[j])
            {
                k=j;
            }
        }
        if(k!=i)
        {
            int tmp=arr[i];
            arr[i]=arr[k];
            arr[k]=tmp;
        }
    }
}

void merge(int arr[],int tmp[],int left, int mid, int right)
{
    int i,j,k;
    i=left;k=left;j=mid+1;

    while(i<=mid && j<=right)
    {
        if(arr[i]<arr[j])
        {
            tmp[k]=arr[i];
            i++;
        }
        else
        {
            tmp[k]=arr[j];
            j++;
        }
        k++;
    }
    while(i<=mid)
    {
        tmp[k++]=arr[i++];
    }
    while(j<=right)
    {
        tmp[k++]=arr[j++];
    }

    for(i=left;i<=right;i++)
    {
        arr[i]=tmp[i];
    }

}

void mergeSort(int arr[],int tmp[],int left, int right)
{
    if(left<right)
    {
        int mid=left+(right-left)/2;

        mergeSort(arr,tmp,left,mid);
        mergeSort(arr,tmp,mid+1,right);
        merge(arr,tmp,left,mid,right);
    }

}

// ���ֺ�����ѡ�����һ��Ԫ����Ϊ��׼Ԫ��
int partition(int arr[], int low, int high)
{
    int pivot = arr[low];

    while(low<high)
    {
        while(low<high && arr[high]>=pivot)
        {
            high--;
        }
        arr[low]=arr[high];

        while(low<high && arr[low]<=pivot)
        {
            low++;
        }
        arr[high]=arr[low];

    }
    arr[low]=pivot;
    return low;
}

// ����������
void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}
