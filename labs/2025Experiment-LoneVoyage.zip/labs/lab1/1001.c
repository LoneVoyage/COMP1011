#include <stdbool.h>
#include <stdio.h>

bool is_valid_op(char c) { return c == '+' || c == '-' || c == '*' || c == '/'; }

int main(void) {
    int lhs, rhs, op = '\0';
    if (scanf("%d", &lhs) != 1)
        return 0;
    
    while ((op = getchar()) != EOF && is_valid_op(op)) {
        if (scanf("%d", &rhs) != 1) {
            op = getchar();
            break;
        }
        switch (op) {
            case '+': lhs += rhs; break;
            case '-': lhs -= rhs; break;
            case '*': lhs *= rhs; break;
            case '/': lhs /= rhs; break;
        }
    }

    if (op == '=')
        printf("%d", lhs);
    else
        printf("错误的运算符:%c", op);
    
    return 0;
}