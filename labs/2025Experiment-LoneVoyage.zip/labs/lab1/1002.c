#include <stdio.h>
#include <stdbool.h>

typedef struct {
    int year, month, day;
} Date;

const unsigned DAYS_IN_MONTH[12 + 1] = {
    0,
    31, 28, 31, 30, 31, 30,
    31, 31, 30, 31, 30, 31,
};
const Date DATE_BEG = {1990, 1, 1};

bool is_valid_date(Date);
int read_date(Date *);
int days_in_month(int month, int year);
int nth_day_in_year(Date);
int days_to_date(Date);

bool is_leap_year(int yr) { return (yr % 4 == 0 && yr % 100 != 0) || yr % 400 == 0; }

int main(void) {
    Date date;

    if (read_date(&date) == 1)
        printf(days_to_date(date) % 5 < 3? "working": "rest");
    else
        printf("Invalid input");

    return 0;
}

bool is_valid_date(Date date) {
    if (date.year < DATE_BEG.year)
        return false;

    if (date.month < 1 || date.month > 12 || date.day < 1)
        return false;

    return date.day <= days_in_month(date.month, date.year);
}

int read_date(Date *date) {
    int read_success = scanf("%4d-%2d-%2d", &date->year, &date->month, &date->day);
    return read_success == 3 && is_valid_date(*date);
}

int days_in_month(int month, int year) {
    if (month == 2)
        return DAYS_IN_MONTH[2] + is_leap_year(year);

    return DAYS_IN_MONTH[month];
}

int nth_day_in_year(Date date) {
    int days = date.day;
    for (int month = 1; month < date.month; month++) {
        days += days_in_month(month, date.year);
    }
    return days;
}

int days_to_date(Date date) {
    int days = nth_day_in_year(date) - nth_day_in_year(DATE_BEG);
    for (int year = DATE_BEG.year + 1; year < date.year; year++) {
        days += 365 + is_leap_year(year);
    }
    return days;
}