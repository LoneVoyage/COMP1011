#include <stdio.h>

void move_disk(int n, char from, char to, char temp) {
    if (n == 0)
        return;

    move_disk(n - 1, from, temp, to);
    printf("Move disk from %c to %c\n", from, to);
    move_disk(n - 1, temp, to, from);
}

int main() {
    int n;
    scanf("%d", &n);
    move_disk(n, 'A', 'C', 'B');
}