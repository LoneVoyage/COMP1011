#include <stdbool.h>
#include <stdio.h>

int max(int a, int b) { return a < b? b: a; }

int max_diff(int *left, int *right) {
    if (left == right)
        return *left;
    
    return max(*left - max_diff(left + 1, right), *right - max_diff(left, right - 1));
}

int main(void) {
    int n;
    scanf("%d", &n);
    int nums[n];
    for (int i = 0; i < n; ++i) {
        scanf("%d", nums + i);
    }
    puts(max_diff(nums, nums + n - 1) >= 0? "true": "false");
    return 0;
}