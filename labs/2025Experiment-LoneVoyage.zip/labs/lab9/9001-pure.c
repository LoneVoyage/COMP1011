#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 栈元素：存储括号类型（{/}/[/]）和所在索引（便于报错定位）
typedef struct {
    char bracket;  // 括号字符
    int position;  // 括号在JSON字符串中的位置（从0开始）
} StackElem;

// 栈结构体（动态扩容，避免固定容量限制）
typedef struct {
    StackElem* data;     // 栈数据数组
    int top;             // 栈顶指针（-1表示空栈）
    int capacity;        // 当前栈容量
    int max_capacity;    // 最大容量
} Stack;

// 栈操作结果枚举（增强健壮性）
typedef enum {
    STACK_OK,           // 操作成功
    STACK_EMPTY,        // 栈空（弹栈/取栈顶失败）
    STACK_FULL,         // 栈满（压栈失败）
    STACK_MEM_ERR       // 内存分配失败
} StackResult;

int stackIsEmpty(const Stack* stack);

// ----------------------------// 学生需实现的栈接口// ----------------------------
// 1. 初始化栈（指定初始容量和最大容量）
StackResult stackInit(Stack* stack, int init_capacity, int max_capacity){
    if (init_capacity <= 0 || max_capacity <= 0 || init_capacity > max_capacity)
        return STACK_MEM_ERR;

    stack->data = malloc(sizeof(StackElem) * init_capacity);
    if (stack->data == NULL)
        return STACK_MEM_ERR;

    stack->top          = -1,
    stack->capacity     = init_capacity,
    stack->max_capacity = max_capacity;

    return STACK_OK;
}

// 2. 压栈（将数据存入栈）
StackResult stackPush(Stack* stack, char bracket, int position){
    if (stack->top + 1 == stack->capacity) {
        if (stack->capacity == stack->max_capacity)
            return STACK_FULL;

        void *data = realloc(stack->data, stack->top + 1);
        if (data == NULL)
            return STACK_MEM_ERR;
        stack->data = data;
        stack->capacity++;
    }
    stack->top++;
    stack->data[stack->top].bracket     = bracket,
    stack->data[stack->top].position    = position;

    return STACK_OK;
}

// 3. 弹栈（取出栈顶元素，通过elem输出）
StackResult stackPop(Stack* stack, StackElem* elem){
    if (stackIsEmpty(stack))
        return STACK_EMPTY;

    *elem = stack->data[stack->top];
    stack->top--;
    return STACK_OK;
}
// 4. 查看栈顶
StackResult stackPeek(Stack* stack, StackElem* elem) {
    if (stackIsEmpty(stack))
        return STACK_EMPTY;

    *elem = stack->data[stack->top];
    return STACK_OK;
}

// 5. 判空（返回1表示空，0表示非空）
int stackIsEmpty(const Stack* stack) {
    return stack->top == -1 ? 1 : 0;
}

// 6. 销毁栈（释放内存）
void stackDestroy(Stack* stack) {
    free(stack->data);
    stack->data     = NULL,
    stack->top      = -1,
    stack->capacity = 0;
}


// 辅助函数
// 判断是否为左括号
int isLeftBracket(char ch) {
    return ch == '{' || ch == '[';
}
// 判断是否为右括号
int isRightBracket(char ch) {
    return ch == '}' || ch == ']';
}
// 判断括号是否匹配
int isBracketMatch(char left, char right) {
    return (left == '{' && right == '}') || (left == '[' && right == ']');
}


// 栈基础版本实现
int jsonBracketCheckBasic(const char *json_str) {
    if (json_str == NULL || *json_str == '\0')
        return 1;
        
    Stack stack;
    stackInit(&stack, 100, 100);
    int idx = -1;
    while (json_str[++idx]) {
        if (isLeftBracket(json_str[idx])) {
            stackPush(&stack, json_str[idx], idx);

        } else if (isRightBracket(json_str[idx])) {
            StackElem elem;
            if (
                stackPop(&stack, &elem) != STACK_OK
                || !isBracketMatch(elem.bracket, json_str[idx])
            ) {
                stackDestroy(&stack);
                return 0;
            }
        }
    }
    int res = stackIsEmpty(&stack);
    stackDestroy(&stack);
    return res;
}

// 栈进阶版本实现
// 学生任务：学习状态管理，理解字符串内的括号不应该参与匹配，同时处理转义字符
int jsonBracketCheckAdvanced(const char *json_str) {
    if (json_str == NULL || *json_str == '\0')
        return 1;

    Stack stack;
    stackInit(&stack, 100, 100);
    int in_string = 0,
        escape = 0;
    int idx = -1;
    while (json_str[++idx]) {
        if (in_string) {
            if (escape) {
                escape = 0;
                continue;
            }

            if (json_str[idx] == '\\') {
                escape = 1;
                
            } else if (json_str[idx] == '"') {
                in_string = 0;
            }
            continue;
        }

        if (json_str[idx] == '"') {
            in_string = 1;

        } else if (isLeftBracket(json_str[idx])) {
            stackPush(&stack, json_str[idx], idx);

        } else if (isRightBracket(json_str[idx])) {
            StackElem elem;
            if (
                stackPop(&stack, &elem) != STACK_OK
                || !isBracketMatch(elem.bracket, json_str[idx])
            ) {
                stackDestroy(&stack);
                return 0;
            }
        }
    }
    int res = stackIsEmpty(&stack) && !in_string;
    stackDestroy(&stack);
    return res;
}

int main(){
    char str[100];
    scanf("%s", str); 
    int result1 = jsonBracketCheckBasic(str);
    int result2 = jsonBracketCheckAdvanced(str);
    printf("%d %d", result1,result2);
}