#ifndef CUSTOMER_H
#define CUSTOMER_H
// 客户结构体：包含客户ID和兴趣分值（核心排序依据）
typedef struct {
    int id;             // 客户唯一标识
    float interest;     // 兴趣分值（越高越优先推荐）
} Customer;
#endif