#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#define MAX_LEN 1024

char *split_and_lower(char *str, char* dst) {
    while (*str && !isalpha(*str)) ++str;
    while (*str && isalpha(*str))
        *dst++ = tolower(*str++);
    return str;
}

bool find_in(char (*beg)[MAX_LEN], char (*end)[MAX_LEN], const char *str) {
    for (char (*it)[MAX_LEN] = beg; it != end; ++it) {
        if (strcmp(*it, str) == 0)
            return true;
    }
    return false;
}

int main(void) {
    char line[MAX_LEN],
        word[MAX_LEN],
        word_table[MAX_LEN][MAX_LEN];
    char (*table_end)[MAX_LEN] = word_table;
    fgets(line, MAX_LEN, stdin);

    char *to_split = line;
    while (*to_split) {
        to_split = split_and_lower(to_split, word);
        if (!find_in(word_table, table_end, word))
            strcpy(table_end++, word);
    }
    printf("%lld\n", table_end - word_table);
    return 0;
}