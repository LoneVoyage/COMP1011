#include <stdio.h>
#include <string.h>

#define MAX_BIT (52)

void swap(char *a, char *b) { char c = *a; *a = *b; *b = c; }
void stoi(char *str) { while (*str) *str++ ^= '0'; }

char *itos(char arr[MAX_BIT]) {
    char *end = arr + MAX_BIT, *it = arr;
    while (*(end - 1) == 0) --end;
    while (it != end)
        *it++ |= '0';
    return arr;
}

char *strrev(char *str) {
    char *beg = str, *end = str + strlen(str);
    while (beg < end)
        swap(beg++, --end);
    return str;
}

int main(void) {
    char data[2][MAX_BIT] = {}, res[MAX_BIT] = {};

    for (int i = 0; i <= 1; ++i) {
        scanf("%s", data[i]);
        stoi(strrev(data[i]));
    }
    
    for (int i = 0; i < MAX_BIT - 1; ++i) {
        res[i] += data[0][i] + data[1][i];
        if (res[i] >= 10) {
            --res[i];
            ++res[i + 1];
        }
    }

    puts(strrev(itos(res)));
    return 0;
}