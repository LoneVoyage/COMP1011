#include <stdbool.h>
#include <stdio.h>

#define MAX_ROW (20)

const char COL_NAME[5] = {'A', 'B', 'C', 'D', 'F'};

int sold_num[MAX_ROW];

int sell(int num, bool *first) {
    for (int i = 0; i < MAX_ROW; ++i) {
        if (5 - sold_num[i] < num)
            continue;
        while (num--) {
            if (*first) *first = false; else putchar(' ');
            printf("%d%c", i + 1, COL_NAME[sold_num[i]++]);
        }
        return 0;
    }
    return num;
}

int main(void) {
    int n;
    scanf("%d", &n);
    while (n--) {
        int num;
        scanf("%d", &num);
        bool first = true;
        if (sell(num, &first) != 0) {
            while (num-- && sell(1, &first) == 0);
        }
        putchar('\n');
    }
    return 0;
}