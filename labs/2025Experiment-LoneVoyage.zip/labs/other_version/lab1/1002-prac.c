#include <stdio.h>
#include <stdbool.h>

const unsigned DAYS_IN_MONTH[12 + 1] = {
    0,
    31, 28, 31, 30, 31, 30,
    31, 31, 30, 31, 30, 31,
};

typedef struct {
    int year, month, day;
} Date;

bool is_leap_year(int);
bool is_valid_date(Date);
int get_days_in_month_now(Date);
int to_next_month(Date *);
int to_next_year(Date *);
int days_to_date(Date);

int main(void) {
    Date date;

    if (
        scanf("%4d-%2d-%2d", &date.year, &date.month, &date.day) == 3
        && is_valid_date(date)
    )
        printf(days_to_date(date) % 5 < 3? "working": "rest");
    else
        printf("Invalid input");
    
    return 0;
}

bool is_leap_year(int year) {
    return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
}

int get_days_in_month_now(Date date) {
    if (date.month == 2)
        return DAYS_IN_MONTH[2] + is_leap_year(date.year);

    return DAYS_IN_MONTH[date.month];
}

bool is_valid_date(Date date) {
    if (
        date.year < 1990
        || date.month < 1
        || date.month > 12
        || date.day < 1
    )
        return false;

    return date.day <= get_days_in_month_now(date);
}

int to_next_month(Date *date) {
    int passed_days;

    passed_days = get_days_in_month_now(*date) - date->day;

    date->month++; date->day = 1;
    if (date->month > 12) {
        date->year++;
        date->month = 1;
    }

    return passed_days;
}

int to_next_year(Date *date) {
    int passed_days = 0;

    while (date->month < 12)
        passed_days += to_next_month(date);

    passed_days += to_next_month(date);

    return passed_days;
}

int days_to_date(Date end_date) {
    Date now_date = {1990, 1, 1};
    int passed_days = 0;

    while (now_date.year != end_date.year)
        passed_days += to_next_year(&now_date);

    while (now_date.month != end_date.month)
        passed_days += to_next_month(&now_date);

    passed_days += end_date.day - now_date.day;

    return passed_days;
}