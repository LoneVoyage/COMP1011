#include <stdio.h>

int add(int *lhs, int rhs) { return *lhs += rhs, 0; }
int sub(int *lhs, int rhs) { return *lhs -= rhs, 0; }
int mult(int *lhs, int rhs) { return *lhs *= rhs, 0; }

int div(int *lhs, int rhs) {
    if (rhs == 0)
        return -1;

    return *lhs /= rhs, 0;
}

int undefined(int *lhs, int rhs) { return -1; }
void init(void);

int (*fn[256]) (int *, int);

int main(void) {
    int lhs, rhs;
    unsigned char op = '\0';   // means undefined
    init();

    if (scanf("%d", &lhs) != 1)         // read lhs OK?
        return 0;

    while (
        scanf("%c%d", &op, &rhs) == 2   // read op and rhs OK?
        && op != '='                    // not meet '='?
        && fn[op](&lhs, rhs) == 0       // no error returns?
    );                                  // then continue

    if (fn[op] != undefined)
        scanf("%c", &op);   // get ending op
    

    if (op == '=')  // meet '='
        printf("%d", lhs);
    else            // invalid op
        printf("错误的运算符:%c", op);
    
    return 0;
}

void init(void) {
    int (**ptr) (int *, int) = fn;
    while (ptr != fn + 256)
        *ptr++ = undefined;

    fn['+'] = add;  fn['-'] = sub;
    fn['*'] = mult; fn['/'] = div;
}