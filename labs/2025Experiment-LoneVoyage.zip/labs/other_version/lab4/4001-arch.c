#include <stdbool.h>
#include <stdio.h>

#define MAX_SEAT (100)

bool is_sold[MAX_SEAT];

bool check_available(int pos, int num);
int find_available(int num);
void name_it(int pos);
void sell_ticket(int pos, int num);

int main(void) {
    int n;
    scanf("%d", &n);
    while (n--) {
        int num;
        scanf("%d", &num);
        sell_ticket(find_available(num), num);
        putchar('\n');
    }
    return 0;
}

bool check_available(int pos, int num) {
    if (pos < 0 || pos >= 100)
        return false;
        
    int end = pos / 5 * 5 + 5 - num;
    if (pos > end)
        return false;
    while (pos <= end) {
        if (is_sold[pos++])
            return false;
    }
    return true;
}

int find_available(int num) {
    for (int pos = 0; pos < 100; ++pos) {
        if (check_available(pos, num))
            return pos;
    }
    return -1;
}

void name_it(int pos) {
    static const char COL_NAME[5] = {'A', 'B', 'C', 'D', 'F'};
    printf("%d%c", pos / 5 + 1, COL_NAME[pos % 5]);
}

void sell_ticket(int pos, int num) {
    bool unavailable = pos < 0 || pos >= 100, first = true;
    while (num-- > 0) {
        if (unavailable)
            pos = find_available(1);
        if (pos < 0 || pos >= 100)
            break;
            
        is_sold[pos] = true;
        if (first) first = false; else putchar(' ');
        name_it(pos++);
    }
}