#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#define MAX_LEN 1024

char *split_and_lower(char *str, char* dst) {
    while (*str && !isalpha(*str)) ++str;
    while (*str && isalpha(*str))
        *dst++ = tolower(*str++);
    return str;
}

int main(void) {
    char line[MAX_LEN],
        word[MAX_LEN],
        word_table[MAX_LEN][MAX_LEN];
    int size = 0;
    fgets(line, MAX_LEN, stdin);

    char *to_split = line;
    while (*to_split) {
        to_split = split_and_lower(to_split, word);
        for (int i = 0; i < size; ++i) {
            if (strcmp(word_table[i], word) == 0)
                goto pass;
        }
        strcpy(word_table[size++], word);
    pass:;
    }
    printf("%d\n", size);
    return 0;
}