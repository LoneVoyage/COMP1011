#include <stdio.h>

int max(int a, int b) { return a > b ? a : b; }
int min(int a, int b) { return a < b ? a : b; }

int main() {
    int n, m, max_sum = 0;
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; ++i) {
        int sum = 0, max_s = 0, min_s = 10;
        for (int j = 0; j < m; ++j) {
            int score;
            scanf("%d", &score);
            sum += score;
            max_s = max(max_s, score);
            min_s = min(min_s, score);
        }
        sum -= max_s + min_s;
        max_sum = max(max_sum, sum);
    }
    printf("%.2lf\n", 1.0 * max_sum / (m - 2));
    return 0;
}
